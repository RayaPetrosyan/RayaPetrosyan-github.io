import { Home, LayoutGrid, BookOpen, Info, User, Search, Bell, CheckCircle2, XCircle, Play, FileText, Terminal, Database, Cloud, Share2, Mail, Globe, ExternalLink } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'motion/react';

const LOGO_URL = "https://lh3.googleusercontent.com/aida-public/AB6AXuAOD1G61oRDV9GkoFQoZBxW-jh6BYRM93SVgxcKR77PnnBnmmWDNSPXd8i5F01LeW8ojGw3AorowKWrMvM8o-DedlMu9Nbt-uFWck3qChiGSBAqtklUrR6JKgSDj_QyRgMCDj1ntuhZ_CvOXtrKLeOEhz9SO7_mJyQ-P0WTyQp3Gkb-sxqyH7Jrgy3N12mtCZYDRtqrbffZxVuWBl5scGR-p5POdj3cqwzdfvWHec2qKsnboYZ1Upb0d-bpIU5vB6wwy4zGFAlIj7A";
const AVATAR_URL = "https://lh3.googleusercontent.com/aida-public/AB6AXuADy3wXht8OFrAMB01QQlAP2H_tfay2nPphle17u62xLgUska1d47p1nebcbrJT9MgDZfFu0Q5vMZRZGlTij0NiySLbVugYFhsxkrq034IQ-q6kSdpwz5YR14A4RbmgCQ9MhUQeneCdpfgMuM-aAWh_WsmigiVJSQmqJckOwD48PRNKq3Y-y4tq87vazDHEFJM8w2JeurkKH-TgzkWJxwc5Ro0usdIZfb4srB1KIS9kCQwoRLh1X7KQ4S2XjYdehXCZ8KUwb9jN9WI";

export function Header() {
  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-primary/10">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3">
          <div className="size-10 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden">
            <img 
              className="w-full h-full object-cover" 
              src={LOGO_URL} 
              alt="GiteliqHub Logo"
              referrerPolicy="no-referrer"
            />
          </div>
          <h1 className="text-xl font-bold tracking-tight text-primary">GiteliqHub</h1>
        </Link>
        
        <nav className="hidden md:flex items-center gap-8">
          <Link to="/" className="text-sm font-medium hover:text-primary transition-colors">Գլխավոր</Link>
          <Link to="/platforms" className="text-sm font-medium hover:text-primary transition-colors">Հարթակներ</Link>
          <Link to="/guides" className="text-sm font-medium hover:text-primary transition-colors">Ուղեցույցներ</Link>
          <Link to="/tools" className="text-sm font-medium hover:text-primary transition-colors">Գործիքներ</Link>
          <Link to="/about" className="text-sm font-medium hover:text-primary transition-colors">Մեր մասին</Link>
        </nav>

        <div className="flex items-center gap-4">
          <button className="p-2 rounded-full hover:bg-primary/10 transition-colors">
            <Search className="size-5 text-slate-600" />
          </button>
          <button className="p-2 rounded-full hover:bg-primary/10 transition-colors">
            <Bell className="size-5 text-slate-600" />
          </button>
          <div className="size-10 rounded-full border-2 border-primary/20 p-0.5">
            <img 
              className="w-full h-full rounded-full object-cover" 
              src={AVATAR_URL} 
              alt="User profile"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </div>
    </header>
  );
}

export function BottomNav() {
  const location = useLocation();
  
  const navItems = [
    { path: '/', label: 'Գլխավոր', icon: Home },
    { path: '/guides', label: 'Ուղեցույցներ', icon: BookOpen },
    { path: '/tools', label: 'Գործիքներ', icon: LayoutGrid },
    { path: '/about', label: 'Մեր մասին', icon: Info },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-md border-t border-primary/10 px-4 pb-6 pt-2 lg:hidden z-50">
      <div className="flex justify-between items-center max-w-md mx-auto">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;
          return (
            <Link 
              key={item.path}
              to={item.path} 
              className={`flex flex-1 flex-col items-center gap-1 transition-colors ${isActive ? 'text-primary' : 'text-slate-400'}`}
            >
              <Icon className={`size-6 ${isActive ? 'fill-primary/10' : ''}`} />
              <span className={`text-[10px] ${isActive ? 'font-bold' : 'font-medium'}`}>{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

export function Footer() {
  return (
    <footer className="hidden lg:block bg-white border-t border-primary/10 py-12 mt-20">
      <div className="max-w-7xl mx-auto px-4 grid grid-cols-4 gap-8">
        <div className="col-span-1">
          <div className="flex items-center gap-2 mb-4">
            <div className="size-8 rounded-full bg-primary/20 flex items-center justify-center overflow-hidden">
              <img src={LOGO_URL} alt="Logo" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            </div>
            <span className="text-lg font-bold text-primary">GiteliqHub</span>
          </div>
          <p className="text-sm text-slate-500">Ձեր ուղեցույցը առցանց կրթության աշխարհում: Միացեք մեզ և զարգացրեք ձեր հմտությունները:</p>
        </div>
        <div>
          <h4 className="font-bold mb-4">Ռեսուրսներ</h4>
          <ul className="space-y-2 text-sm text-slate-500">
            <li><Link to="/guides" className="hover:text-primary transition-colors">Դասընթացներ</Link></li>
            <li><Link to="/tools" className="hover:text-primary transition-colors">Գործիքներ</Link></li>
            <li><Link to="/platforms" className="hover:text-primary transition-colors">Հարթակներ</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-bold mb-4">Աջակցություն</h4>
          <ul className="space-y-2 text-sm text-slate-500">
            <li><a href="#" className="hover:text-primary transition-colors">Հաճախ տրվող հարցեր</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">Կապ մեզ հետ</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">Օգնության կենտրոն</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-bold mb-4">Հետևեք մեզ</h4>
          <div className="flex gap-4">
            <a href="#" className="size-10 rounded-full bg-primary/10 flex items-center justify-center text-primary hover:bg-primary hover:text-white transition-all">
              <Globe className="size-5" />
            </a>
            <a href="#" className="size-10 rounded-full bg-primary/10 flex items-center justify-center text-primary hover:bg-primary hover:text-white transition-all">
              <Share2 className="size-5" />
            </a>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 mt-12 pt-8 border-t border-primary/5 text-center text-xs text-slate-400">
        © 2024 GiteliqHub. Բոլոր իրավունքները պաշտպանված են:
      </div>
    </footer>
  );
}
