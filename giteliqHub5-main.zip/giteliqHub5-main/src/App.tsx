import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Header, BottomNav, Footer } from './components/Navigation';
import Home from './pages/Home';
import Tools from './pages/Tools';
import Guides from './pages/Guides';
import Platforms from './pages/Platforms';
import About from './pages/About';

export default function App() {
  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 pb-24 lg:pb-0">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/tools" element={<Tools />} />
            <Route path="/guides" element={<Guides />} />
            <Route path="/platforms" element={<Platforms />} />
            <Route path="/about" element={<About />} />
          </Routes>
        </main>
        <BottomNav />
        <Footer />
      </div>
    </Router>
  );
}
