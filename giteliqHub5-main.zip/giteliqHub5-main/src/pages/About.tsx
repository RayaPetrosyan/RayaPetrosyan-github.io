import { motion } from 'motion/react';
import { Rocket, Eye, Users, Lightbulb, ShieldCheck, Maximize2 } from 'lucide-react';

const VALUES = [
  { label: "Համայնք", icon: Users },
  { label: "Նորարարություն", icon: Lightbulb },
  { label: "Որակ", icon: ShieldCheck },
  { label: "Հասանելիություն", icon: Maximize2 }
];

const TEAM = [
  {
    name: "Արամ Մկրտչյան",
    role: "Հիմնադիր և Տնօրեն",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDAnt5VH_rOJ3JLZERhujRp6KsF24nh9VSex6HC3GKHf88-mDax_75jj-DvvGcJKx4yvivwuE595YLSxBxdtwkEAPrPg7EuxF7wPuvvPLvv7rxxNxir7d85r9Mpjri5MnxmgqfuZ9Ht3t6e7AzXGzh_yY0dnSR1vpA358ToQyt2008znvqFoy5i6X9ffCw6k3rEPp1LQx9B2bMjsW6vO2c8znNzvN4VCWBDratxCPiVyXVxov6Fox_PJEx6p7mtCtpo_STeHWdc1jc"
  },
  {
    name: "Անի Գևորգյան",
    role: "Կրթական Ծրագրերի Ղեկավար",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBG1zg70Mg33kp9aG7M5ixL_lGHL-bw0WvhK3H6ooS7JcARqbW0LPPGL0bC-RCAyGkPmcRaA2Evbz07Xm7UzHocIQZXRtePQtqtJsHfQ3EFW-i98JBtyBmVBFJi-QUq8H2E6YCNB5FabYkMrM35AjtDaciLqMeQ-C1rOsWD3TPq1MK6X58oV1k_X64o8SwLussoaxdnycd9q2ewQGJB_aH1PRm-RtYQY_o3s5gnxkJqn5rfOKgoyiisafxY0tSCK1i6JM74bYPnCQw"
  },
  {
    name: "Կարեն Սարգսյան",
    role: "Գլխավոր Մասնագետ",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDimih88qxBn5ZeugESzholh44NIOKCwnakgMqzRI2alpQ_lq2Ycmi-MEWNWTrncDg6QqKZg7qSo7mzRaxCHwpK9UvEnLX_UvFX7JSOUVkUVIpWjQ_SXF3ULKPdSmKMn9igEf_2diHOB_8OqHYAJnVna-XU79nCRkhYFBMDD0ezmGrCQWodk1shC8PV-wso2qwjygNDQ2IDmhUOqQV3F08CcceiQ6QbsL6NP2XjKqT8gqnS6LAL9s26JrFOdPJQ-h1dMIiB3eYn3lo"
  }
];

export default function About() {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-5xl mx-auto px-4 py-8"
    >
      <section className="mb-12">
        <div className="relative h-64 md:h-80 rounded-xl overflow-hidden mb-8">
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent z-10"></div>
          <img 
            alt="Team working" 
            className="w-full h-full object-cover" 
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuB74hMWK4HrAvS0eEdAfV6zuLOeS0Gf4BRw0Myu3bkw5JL5Q8OzgPqBkfRT3ycd-pEzpXqi50zr93iaZ11p7T0-YZ1qjexXNSNifgh0t4co2RW6rDms-o3D5yCuGzmnmHJlJlsACmhtPlKncOwBJuYusMOugBWjV0gcwUrIBRJUHBEGkF8fWCYJyVQSB0Z63fYiB-QSOVNukslttchqk3Kh0WyI6SyXU5Mo4nt-cxkwwPNao1J1nfKLX16BVUb2KoeU8Fo0shMquBM" 
            referrerPolicy="no-referrer"
          />
          <div className="absolute bottom-6 left-6 z-20">
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">Մեր մասին</h1>
            <p className="text-slate-200 max-w-md">Կառուցում ենք հայկական կրթական ապագան միասին:</p>
          </div>
        </div>
      </section>

      <section className="grid md:grid-cols-2 gap-6 mb-16">
        <motion.div 
          whileHover={{ y: -5 }}
          className="bg-white p-8 rounded-xl border border-slate-100 shadow-sm"
        >
          <div className="size-12 bg-primary/10 text-primary rounded-lg flex items-center justify-center mb-6">
            <Rocket className="size-8" />
          </div>
          <h2 className="text-2xl font-bold mb-4">Մեր Առաքելությունը</h2>
          <p className="text-slate-600 leading-relaxed">
            GiteliqHub-ի նպատակն է հզորացնել հայկական կրթական համայնքը՝ ապահովելով հասանելի և որակյալ գիտելիք բոլորի համար։ Մենք հավատում ենք, որ կրթությունը պետք է լինի ժամանակակից, հետաքրքիր և արդյունավետ։
          </p>
        </motion.div>
        <motion.div 
          whileHover={{ y: -5 }}
          className="bg-white p-8 rounded-xl border border-slate-100 shadow-sm"
        >
          <div className="size-12 bg-primary/10 text-primary rounded-lg flex items-center justify-center mb-6">
            <Eye className="size-8" />
          </div>
          <h2 className="text-2xl font-bold mb-4">Մեր Տեսլականը</h2>
          <p className="text-slate-600 leading-relaxed">
            Դառնալ առաջատար հարթակ, որտեղ հայ մասնագետները կարող են կիսվել իրենց փորձով, իսկ սովորողները ստանալ գործնական հմտություններ՝ մրցունակ լինելու համար համաշխարհային շուկայում։
          </p>
        </motion.div>
      </section>

      <section className="mb-16">
        <h2 className="text-2xl font-bold text-center mb-10">Մեր Արժեքները</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {VALUES.map((val) => {
            const Icon = val.icon;
            return (
              <div key={val.label} className="flex flex-col items-center text-center p-6">
                <div className="size-16 bg-blue-50 rounded-full flex items-center justify-center mb-4">
                  <Icon className="text-primary size-8" />
                </div>
                <h3 className="font-semibold">{val.label}</h3>
              </div>
            );
          })}
        </div>
      </section>

      <section className="mb-16">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold">Մեր Թիմը</h2>
          <a className="text-primary font-medium hover:underline" href="#">Միացիր մեզ</a>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {TEAM.map((member, idx) => (
            <motion.div 
              key={member.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white rounded-xl overflow-hidden border border-slate-100 group"
            >
              <div className="h-48 bg-slate-200 overflow-hidden">
                <img 
                  src={member.image} 
                  alt={member.name} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-4 text-center">
                <h4 className="font-bold text-lg">{member.name}</h4>
                <p className="text-slate-500 text-sm">{member.role}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>
    </motion.div>
  );
}
