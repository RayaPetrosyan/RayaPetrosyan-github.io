import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight, BookOpen, LayoutGrid, Globe, Users } from 'lucide-react';

const FEATURES = [
  { title: "Ուղեցույցներ", description: "Տեսական և գործնական դասեր", icon: BookOpen, path: "/guides", color: "bg-blue-500" },
  { title: "Գործիքներ", description: "Լավագույն ծրագրային լուծումները", icon: LayoutGrid, path: "/tools", color: "bg-purple-500" },
  { title: "Հարթակներ", description: "Ուսումնական միջավայրեր", icon: Globe, path: "/platforms", color: "bg-orange-500" },
  { title: "Մեր մասին", description: "Ծանոթացեք մեր թիմին", icon: Users, path: "/about", color: "bg-green-500" },
];

export default function Home() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <section className="text-center mb-20">
        <motion.h1 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl md:text-6xl font-bold mb-6 tracking-tight"
        >
          Բարի գալուստ <span className="text-primary">GiteliqHub</span>
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-xl text-slate-600 max-w-2xl mx-auto mb-10"
        >
          Ձեր ամբողջական ուղեցույցը հայկական կրթական տիրույթում: Գտեք լավագույն գործիքները և դասընթացները մեկ վայրում:
        </motion.p>
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4 }}
          className="flex flex-wrap justify-center gap-4"
        >
          <Link to="/guides" className="px-8 py-4 bg-primary text-white rounded-full font-bold hover:opacity-90 transition-opacity flex items-center gap-2">
            Սկսել հիմա <ArrowRight className="size-5" />
          </Link>
          <Link to="/about" className="px-8 py-4 bg-white border border-slate-200 rounded-full font-bold hover:bg-slate-50 transition-colors">
            Իմանալ ավելին
          </Link>
        </motion.div>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {FEATURES.map((feature, idx) => {
          const Icon = feature.icon;
          return (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 + idx * 0.1 }}
            >
              <Link 
                to={feature.path}
                className="block p-8 bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md hover:border-primary/20 transition-all group h-full"
              >
                <div className={`size-12 ${feature.color} text-white rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                  <Icon className="size-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-slate-500 text-sm">{feature.description}</p>
              </Link>
            </motion.div>
          );
        })}
      </section>

      <section className="mt-24 bg-primary/5 rounded-3xl p-8 md:p-16 text-center">
        <h2 className="text-3xl font-bold mb-6">Պատրա՞ստ եք սկսել</h2>
        <p className="text-slate-600 mb-10 max-w-xl mx-auto">Միացեք հազարավոր հայ ուսանողների և մասնագետների, ովքեր արդեն օգտվում են GiteliqHub-ի հնարավորություններից:</p>
        <button className="px-10 py-4 bg-primary text-white rounded-full font-bold shadow-lg shadow-primary/20 hover:scale-105 transition-transform">
          Գրանցվել անվճար
        </button>
      </section>
    </div>
  );
}
