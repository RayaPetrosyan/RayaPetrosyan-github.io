import { motion } from 'motion/react';
import { CheckCircle2, XCircle, ExternalLink } from 'lucide-react';

const TOOLS = [
  {
    name: "Zoom",
    category: "Վիդեոկապ",
    description: "Տեսակոնֆերանսների և առցանց հանդիպումների ամենահայտնի հարթակը, որն ապահովում է բարձր որակի կապ:",
    pros: "Կայուն կապ, ձայնագրման հնարավորություն:",
    cons: "40 րոպե սահմանափակում անվճար տարբերակում:",
    icon: "https://lh3.googleusercontent.com/aida-public/AB6AXuCD3B2AprbWgHF3AaexwhtwOHcQ16Rm-rW08wTJ7ZJrSCJ6NDK63I7LhxKA9qzSIo5HwDF8caMXo32CCJKGzovfNTCrckW8JZjWw7alQbc4FTTK7e3yoPII_PcN8vF7baXINsbI64ehoa9Kv30d05q3nD9gZQaprljhiqNW9PzAKXutb23mE89I7OeMDBUJuELI0tI5F39l9fAJsO-l8liFpZs8kYkz7b-QfPraQtFV-TzG9YwnaLG3qkFxRPEqv7yyEqOU8Pxwvy8",
    color: "bg-blue-50 border-blue-100",
    badgeColor: "bg-green-100 text-green-700"
  },
  {
    name: "Slack",
    category: "Թիմային աշխատանք",
    description: "Աշխատանքային հաղորդակցության հարթակ, որը հնարավորություն է տալիս կազմակերպել թիմային քննարկումները ըստ ալիքների:",
    pros: "Հարմար ինտեգրումներ, ֆայլերի կառավարում:",
    cons: "Հին հաղորդագրությունների սահմանափակում:",
    icon: "https://lh3.googleusercontent.com/aida-public/AB6AXuBm1T13UAzmUaQM05u-0HaSy2ns6TTpd75GBQGlsGJ28so86m2sEQgjIKoiNBAwzFVbhmJLoh4Bap_n3kcMP4DTwxp8lhCQYwHbe_MTXeuhHCkkaJ3nvI3n_qLAjb1bezlVpm7VDeaWZ9dopnM2h-Od16XVx15NVovKNhE_-oEiCOCCCjFv9Ihd-vdMQU6eAFTwOVMJmtQi0XCrfJWbwecadp6URrzAaDt65LMx6UewIxynZ8OUuIvBngY2F5UcIg7mxYcx1uNSw4Q",
    color: "bg-purple-50 border-purple-100",
    badgeColor: "bg-purple-100 text-purple-700"
  },
  {
    name: "Google Meet",
    category: "Վիդեոկապ",
    description: "Անվճար վիդեոկապի հարթակ Google-ի կողմից, որը ինտեգրված է Gmail-ի և Google Calendar-ի հետ:",
    pros: "Լիովին անվճար, պարզ ինտերֆեյս:",
    cons: "Ավելի քիչ ֆունկցիաներ քան Zoom-ում:",
    icon: "https://lh3.googleusercontent.com/aida-public/AB6AXuDxZ_l0X7OfIYty7orbfpchtZ-xu5M1NvwyLZpRl4txsfEFnA8UcYGK8CAESji9xI4omp5Qs5BgkNhd9FBXrtIPz8DKINnaB2xPGGtYy2At3UMCVpzRoJit1BPurfG3qS4G5wGdMcPuX9rag2npQhl1g6U4iKT7LOB5j_JV7RpLufyUq-PssTK6Aw9Wv5AbMFY7KoCm_AE4JijlFjZpwmBObDgwaItvO6GhOdAsqGhrfo4a-nqPeW82721ejMGfeDBUhpgudr4TQJs",
    color: "bg-orange-50 border-orange-100",
    badgeColor: "bg-orange-100 text-orange-700"
  },
  {
    name: "Yandex Telemost",
    category: "Վիդեոկապ",
    description: "Արագ և պարզ տեսազանգերի գործիք, որը չի պահանջում գրանցում կամ լրացուցիչ ծրագրեր:",
    pros: "Անսահմանափակ ժամանակ, հեշտ հասանելիություն:",
    cons: "Քիչ կարգավորումներ խմբերի համար:",
    icon: "https://lh3.googleusercontent.com/aida-public/AB6AXuC7uQ-S3Zgrh7qhZFbAKEMphJPgsSyp1PYlXdBh9G-RIK5sqc1a9mrQabSbhUBa2askrhf8wWNdEvHVPfSCU35hwILGg4iDRSzfnxPOAC0H99PraUciNPiid4T7nrlBbNTdHZ2SCUmjMtXiwdbwEmH1YmNkU_kob2CT8q1zS1FlBVYBWOMMl5arYwRWA1YjJg7DBL_EVi__7n_UYBOhE8Y0q0v6D1tAg_Hq7KcScML6ITYUONhNlqRMGqI3rMzxThG980VLU4_OXlI",
    color: "bg-yellow-50 border-yellow-100",
    badgeColor: "bg-yellow-100 text-yellow-700"
  },
  {
    name: "Telegram",
    category: "Մեսենջեր",
    description: "Բազմաֆունկցիոնալ մեսենջեր, որը հիանալի է կրթական խմբեր և ալիքներ ստեղծելու համար:",
    pros: "Մեծ ֆայլերի փոխանցում, բոտերի համակարգ:",
    cons: "Անվտանգության որոշակի հարցեր հանրային խմբերում:",
    icon: "https://lh3.googleusercontent.com/aida-public/AB6AXuBNDSKmX5f_71JN689wzb-NpizFkzA_tFcQ_5kh9hWR1FWnyf7UzDI9EFdyeu5fRZCbD1FuGhmw0WNWWxlEcUogMS_JPoMhviKOJAbcm6ClxLyBBZcO75ChqyRHxDfZgBtqKmCsuDIq8en1ulb8yej62Llc1O1_Vgs9K7ZnrfeoW6yADe-vvLThnt2jW8okt5w4PEi6GLN8uaqqacTi4X1daWJ8262P08-OuG2tyj08J7sOB73ipOC5ASv_ujVLlpypI_ZF6cYilOY",
    color: "bg-cyan-50 border-cyan-100",
    badgeColor: "bg-cyan-100 text-cyan-700"
  },
  {
    name: "Notion",
    category: "Կազմակերպում",
    description: "Ամենաճկուն գործիքը գրառումներ կատարելու, նախագծեր կառավարելու և տվյալների բազաներ ստեղծելու համար:",
    pros: "Էսթետիկ դիզայն, անսահմանափակ հնարավորություններ:",
    cons: "Ունի ուսուցման բարդ կոր:",
    icon: "https://lh3.googleusercontent.com/aida-public/AB6AXuD8BPBaWN85GnYKpl6cq_qHoeo5MabgZGcUTmag09y3r8BDM6xZwvZCaSIVezKAPeJpB3DZvPetsilnC8z1M9zo9JVHzFw07l44ROsW0B-89tbO5vPUToVXc5xGIaSPyRnyaOfxhoC5KGp_iIDf_3D9nGo6vL8mL6qllHd4430qVeiR3d3JT1EvQBJ5_EiPuJyksSW0yCrifFpgNXTc6CiUokjprkGEO9YPpu_g-UM3LkIRPPNW5eyUXOtfcHgIMjokzpIs-dxrtCw",
    color: "bg-gray-50 border-gray-100",
    badgeColor: "bg-gray-100 text-gray-700"
  }
];

export default function Tools() {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-7xl mx-auto px-4 py-8"
    >
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Գործիքամիջոցներ</h2>
        <p className="text-slate-600">Լավագույն հարթակները առցանց կրթության և հաղորդակցության համար</p>
      </div>

      <div className="flex overflow-x-auto gap-2 pb-4 no-scrollbar mb-8">
        <button className="px-6 py-2.5 bg-primary text-white rounded-full font-medium whitespace-nowrap">Բոլորը</button>
        <button className="px-6 py-2.5 bg-primary/10 text-primary rounded-full font-medium whitespace-nowrap hover:bg-primary/20 transition-colors">Վիդեոկապ</button>
        <button className="px-6 py-2.5 bg-primary/10 text-primary rounded-full font-medium whitespace-nowrap hover:bg-primary/20 transition-colors">Հաղորդակցություն</button>
        <button className="px-6 py-2.5 bg-primary/10 text-primary rounded-full font-medium whitespace-nowrap hover:bg-primary/20 transition-colors">Կրթական</button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {TOOLS.map((tool, idx) => (
          <motion.div 
            key={tool.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="bg-white rounded-xl p-6 shadow-sm border border-primary/5 flex flex-col h-full hover:shadow-md transition-shadow"
          >
            <div className="flex items-center gap-4 mb-4">
              <div className={`size-14 rounded-2xl ${tool.color} flex items-center justify-center overflow-hidden border`}>
                <img className="w-10 h-10" src={tool.icon} alt={tool.name} referrerPolicy="no-referrer" />
              </div>
              <div>
                <h3 className="text-xl font-bold">{tool.name}</h3>
                <span className={`text-xs font-semibold px-2 py-0.5 ${tool.badgeColor} rounded-full`}>{tool.category}</span>
              </div>
            </div>
            <p className="text-slate-600 text-sm mb-4 flex-grow">
              {tool.description}
            </p>
            <div className="space-y-3 mb-6">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="size-5 text-green-500 shrink-0" />
                <p className="text-xs text-slate-500 italic">Առավելություններ՝ {tool.pros}</p>
              </div>
              <div className="flex items-start gap-2">
                <XCircle className="size-5 text-red-400 shrink-0" />
                <p className="text-xs text-slate-500 italic">Թերություններ՝ {tool.cons}</p>
              </div>
            </div>
            <button className="w-full py-3 bg-primary text-white rounded-full font-bold text-center hover:opacity-90 transition-opacity flex items-center justify-center gap-2">
              Պաշտոնական կայք <ExternalLink className="size-4" />
            </button>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
