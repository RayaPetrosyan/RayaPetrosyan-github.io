import { motion } from 'motion/react';
import { Video, Users, School, Presentation, CheckCircle2, XCircle } from 'lucide-react';

const PLATFORMS = [
  {
    name: "Webinar",
    description: "Հզոր հարթակ առցանց սեմինարների և դասախոսությունների անցկացման համար։ Հարմար է մեծ լսարանների համար։",
    pros: ["Բարձր որակ", "Մեծ լսարան"],
    cons: ["Վճարովի փաթեթներ"],
    icon: Video,
    iconBg: "bg-primary/10 text-primary"
  },
  {
    name: "MS Teams",
    description: "Microsoft-ի կողմից մշակված հարթակ՝ թիմային աշխատանքի և հաղորդակցության համար։",
    pros: ["Office 365 ինտեգրում", "Անվտանգություն"],
    cons: ["Բարդ ինտերֆեյս"],
    icon: Users,
    iconBg: "bg-purple-100 text-purple-600"
  },
  {
    name: "Moodle",
    description: "Բաց կոդով ուսումնական հարթակ (LMS), որը հնարավորություն է տալիս ստեղծել անհատականացված դասընթացներ։",
    pros: ["Բաց կոդ", "Ճկունություն"],
    cons: ["Սերվերային պահանջներ"],
    icon: School,
    iconBg: "bg-orange-100 text-orange-600"
  },
  {
    name: "Google Classroom",
    description: "Անվճար վեբ ծառայություն, որը պարզեցնում է առաջադրանքների ստեղծումը, բաշխումը և գնահատումը։",
    pros: ["Լիովին անվճար", "Պարզ օգտագործում"],
    cons: ["Սահմանափակ ֆունկցիաներ"],
    icon: Presentation,
    iconBg: "bg-green-100 text-green-600"
  }
];

export default function Platforms() {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-7xl mx-auto px-4 py-8"
    >
      <div className="mb-10 text-center md:text-left">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">Ուսումնական Հարթակներ</h1>
        <p className="text-slate-600 max-w-2xl">Բացահայտեք լավագույն գործիքները առցանց կրթության և համագործակցության համար։ Մենք հավաքել ենք ամենատարածված հարթակները մեկ տեղում։</p>
      </div>

      <div className="flex flex-wrap gap-2 mb-8 border-b border-slate-200 pb-4">
        <button className="px-6 py-2 rounded-full bg-primary text-white text-sm font-semibold">Բոլորը</button>
        <button className="px-6 py-2 rounded-full bg-white border border-slate-200 text-sm font-medium hover:border-primary transition-colors">Վիդեոկոնֆերանս</button>
        <button className="px-6 py-2 rounded-full bg-white border border-slate-200 text-sm font-medium hover:border-primary transition-colors">LMS</button>
        <button className="px-6 py-2 rounded-full bg-white border border-slate-200 text-sm font-medium hover:border-primary transition-colors">Համագործակցություն</button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {PLATFORMS.map((platform, idx) => {
          const Icon = platform.icon;
          return (
            <motion.div 
              key={platform.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white rounded-xl overflow-hidden shadow-sm border border-slate-100 flex flex-col md:flex-row h-full hover:shadow-md transition-shadow"
            >
              <div className="md:w-1/3 bg-slate-50 flex items-center justify-center p-8">
                <div className={`w-24 h-24 rounded-2xl ${platform.iconBg} flex items-center justify-center`}>
                  <Icon className="size-12" />
                </div>
              </div>
              <div className="md:w-2/3 p-6 flex flex-col">
                <h3 className="text-xl font-bold mb-2">{platform.name}</h3>
                <p className="text-slate-600 text-sm mb-4">{platform.description}</p>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-green-600 mb-1 block">Առավելություններ</span>
                    <ul className="text-xs space-y-1 text-slate-500">
                      {platform.pros.map(pro => (
                        <li key={pro} className="flex items-center gap-1"><CheckCircle2 className="size-3" /> {pro}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-red-600 mb-1 block">Թերություններ</span>
                    <ul className="text-xs space-y-1 text-slate-500">
                      {platform.cons.map(con => (
                        <li key={con} className="flex items-center gap-1"><XCircle className="size-3" /> {con}</li>
                      ))}
                    </ul>
                  </div>
                </div>
                <div className="mt-auto">
                  <button className="w-full bg-primary text-white py-2 rounded font-medium hover:bg-primary/90 transition-colors">Այցելել պաշտոնական կայք</button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}
