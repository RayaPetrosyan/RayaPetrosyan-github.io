import { motion } from 'motion/react';
import { Play, Terminal, Database, Cloud, Search, PlayCircle, FileText, Wrench, Globe } from 'lucide-react';

const VIDEO_GUIDES = [
  {
    title: "Ինչպես սկսել React-ի ուսումնասիրությունը",
    category: "Frontend",
    author: "Արմեն Սարգսյան",
    views: "2.4k",
    duration: "12:45",
    thumbnail: "https://lh3.googleusercontent.com/aida-public/AB6AXuDncOzG9TOdUFyu90QQMTsnLWfXfoubHBD-ckXMfguCy-Td7AB4Vb6T6pJHLPt5VxmY1bDzIsqX4lJbgUxOqPUsroJPYKvlQyQVh4a4J1dQI0SegoClG5N55diUcCogITrbxriY9yE6SiMsuX7Ile2-AvgNEUGFUJk0RruWDnMvNiYwHDN17p7iQAQT0oUFiPqYs2a4vQWhOmhk9axP2pBst7D9f_FNjwSOXj-vlBeAVMicrIRhl5xirQ0goYuW96E6Dsx1Rbmdqhc"
  },
  {
    title: "Git-ի հիմունքները սկսնակների համար",
    category: "Git / GitHub",
    author: "Աննա Հարությունյան",
    views: "1.8k",
    duration: "08:20",
    thumbnail: "https://lh3.googleusercontent.com/aida-public/AB6AXuB3onV8E38iOlftrKX6dnmlFAFZh1UujbXlL91w4Fbiul_V6HmeSQu8aOkiS4EOVQc5JMUnusdSBfmGyKabyrnGqct1DV-PTiD1iY1zf3nzv2TCfuVx9y-OlaqadI4e3KdCGy_0cM9L1z1FcIc8dX9EpavmH6CVNOha3hQOUOv2CwDZqEl4n4j4-gLliExU1UWju0Cs2o8OwGbYC9sbyziIfFiBhbTM4wo6p97fuUS-11k64Tkt4h3jR_p6ZUFZrxDjZgHD6S6NmKI"
  },
  {
    title: "Figma-ի հիմնական գործիքները",
    category: "UI/UX Design",
    author: "Կարեն Գևորգյան",
    views: "3.2k",
    duration: "15:10",
    thumbnail: "https://lh3.googleusercontent.com/aida-public/AB6AXuCiLzjSn994wZlQjJgrw--_DWYJffDXpqS5B3CX4yWcJw0NZKJT-69ZU6W7N7DHsAyN79Xz93nng9njdboRVTUeMGspn2DOAaozj4UyF-1wcq5qNFGPlO2NpzLHTLbxKbAMvKktHmBoCgTxarCaeJF040vrS5YVvxgoZG5WoetldNAmsPQOwXRK4z2AG9TnNJq3_svYOGLOyLRuRMfYpouNf6ZE_yr_VMDkPA2OiRJKLQ2sJDnJ6ZTZL2u3B2zwxHBWVqa4ApLWnFQ"
  }
];

const TEXT_GUIDES = [
  {
    title: "Ինչպես կարգավորել VS Code-ը արդյունավետ աշխատանքի համար",
    category: "DevOps",
    readTime: "5 րոպե",
    description: "Բացահայտեք լավագույն extension-ները և թեմաները, որոնք կդարձնեն ձեր կոդավորումը ավելի արագ և հաճելի:",
    icon: Terminal
  },
  {
    title: "SQL-ի հիմունքները. Աղյուսակների ստեղծում և կառավարում",
    category: "Backend",
    readTime: "8 րոպե",
    description: "Ամբողջական ուղեցույց տվյալների բազաների հետ աշխատելու համար՝ սկսած SELECT հարցումներից մինչև բարդ JOIN-ներ:",
    icon: Database
  },
  {
    title: "AWS-ի հիմունքները սկսնակների համար",
    category: "Cloud",
    readTime: "12 րոպե",
    description: "Ինչպես տեղակայել ձեր առաջին վեբ հավելվածը ամպային տիրույթում՝ օգտագործելով EC2 և S3 ծառայությունները:",
    icon: Cloud
  }
];

export default function Guides() {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-7xl mx-auto px-4 py-8"
    >
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-6">Ուղեցույցներ</h2>
        <div className="relative group">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <Search className="size-5 text-slate-400 group-focus-within:text-primary transition-colors" />
          </div>
          <input 
            className="block w-full pl-12 pr-4 py-4 bg-white border-none rounded-xl shadow-sm focus:ring-2 focus:ring-primary text-base" 
            placeholder="Փնտրել վիդեոդասեր կամ հոդվածներ..." 
            type="text"
          />
        </div>
      </div>

      <div className="flex gap-3 overflow-x-auto pb-4 no-scrollbar mb-8">
        <button className="flex h-10 shrink-0 items-center justify-center gap-2 rounded-full bg-primary text-white px-5 text-sm font-medium">
          Բոլորը
        </button>
        <button className="flex h-10 shrink-0 items-center justify-center gap-2 rounded-full bg-white text-slate-700 px-5 text-sm font-medium border border-slate-200 hover:border-primary transition-colors">
          <PlayCircle className="size-4" /> Վիդեո դասեր
        </button>
        <button className="flex h-10 shrink-0 items-center justify-center gap-2 rounded-full bg-white text-slate-700 px-5 text-sm font-medium border border-slate-200 hover:border-primary transition-colors">
          <FileText className="size-4" /> Տեքստային
        </button>
        <button className="flex h-10 shrink-0 items-center justify-center gap-2 rounded-full bg-white text-slate-700 px-5 text-sm font-medium border border-slate-200 hover:border-primary transition-colors">
          <Wrench className="size-4" /> Գործիքներ
        </button>
        <button className="flex h-10 shrink-0 items-center justify-center gap-2 rounded-full bg-white text-slate-700 px-5 text-sm font-medium border border-slate-200 hover:border-primary transition-colors">
          <Globe className="size-4" /> Պլատֆորմներ
        </button>
      </div>

      <section className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold flex items-center gap-2">
            <PlayCircle className="text-primary" /> Վիդեո դասընթացներ
          </h3>
          <a className="text-primary text-sm font-semibold hover:underline" href="#">Տեսնել բոլորը</a>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {VIDEO_GUIDES.map((guide, idx) => (
            <motion.div 
              key={guide.title}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.1 }}
              className="group bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all border border-slate-100"
            >
              <div className="relative aspect-video">
                <img 
                  src={guide.thumbnail} 
                  alt={guide.title} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center shadow-lg">
                    <Play className="text-white fill-white size-6" />
                  </div>
                </div>
                <span className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded font-medium">{guide.duration}</span>
              </div>
              <div className="p-4">
                <span className="text-[10px] font-bold uppercase tracking-wider text-primary bg-primary/10 px-2 py-1 rounded-md mb-2 inline-block">{guide.category}</span>
                <h4 className="font-bold text-lg mb-1 group-hover:text-primary transition-colors line-clamp-2">{guide.title}</h4>
                <p className="text-sm text-slate-500 line-clamp-1">{guide.author} • {guide.views} դիտում</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold flex items-center gap-2">
            <FileText className="text-primary" /> Տեքստային ուղեցույցներ
          </h3>
          <a className="text-primary text-sm font-semibold hover:underline" href="#">Տեսնել բոլորը</a>
        </div>
        <div className="space-y-4">
          {TEXT_GUIDES.map((guide, idx) => {
            const Icon = guide.icon;
            return (
              <motion.div 
                key={guide.title}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="flex flex-col md:flex-row gap-6 p-5 bg-white rounded-xl border border-slate-100 hover:border-primary/30 transition-all shadow-sm"
              >
                <div className="w-full md:w-48 h-32 rounded-lg bg-primary/5 flex items-center justify-center shrink-0">
                  <Icon className="text-primary size-12" />
                </div>
                <div className="flex flex-col justify-center">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-xs font-semibold text-primary px-2 py-0.5 rounded bg-primary/10">{guide.category}</span>
                    <span className="text-xs text-slate-400">{guide.readTime} ընթերցանություն</span>
                  </div>
                  <h4 className="text-lg font-bold mb-2">{guide.title}</h4>
                  <p className="text-slate-500 text-sm line-clamp-2">{guide.description}</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>
    </motion.div>
  );
}
